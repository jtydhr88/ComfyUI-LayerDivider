=======
Credits
=======

Development Lead
----------------

* Michael Droettboom <mdboom@gmail.com>

Parts of this code were inspired by `psd-tools
<https://github.com/psd-tools/psd-tools/>`__, so a huge thanks to
Mikhail Korobov and the rest of the psd-tools team.

Contributors
------------
